
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class App {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Botão");
        JButton botao = new JButton("Free Robux");

        botao.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Trollei"));
        frame.add(botao);
        frame.setSize(500,500);
        frame.setLayout (new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }

}
